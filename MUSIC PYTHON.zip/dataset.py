import tkinter as tk
from tkinter import filedialog, ttk
import pandas as pd
from tkinter import messagebox
import matplotlib.pyplot as plt
import webbrowser
class MusicApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Music Dataset Explore")
        self.root.geometry("700x400")
        self.root.resizable(0,0)
        self.data = None
        self.top_songs_data = None
        self.root.configure(background='#E6E6FA')
        upload_btn = tk.Button(root, text="Upload Dataset", command=self.load_file)
        upload_btn.pack(pady=10)
        self.year_var = tk.StringVar()
        self.genre_var = tk.StringVar()

        self.year_dropdown = ttk.Combobox(root, textvariable=self.year_var, state="readonly")
        self.year_dropdown.pack(pady=5)

        self.genre_dropdown = ttk.Combobox(root, textvariable=self.genre_var, state="readonly")
        self.genre_dropdown.pack(pady=5)

        filter_btn = tk.Button(root, text="Apply Filters", command=self.apply_filters)
        filter_btn.pack(pady=10)
        chart_btn_frame = tk.Frame(root)
        chart_btn_frame.pack(pady=10)

        bar_btn = tk.Button(chart_btn_frame, text="Top Songs Bar Chart", command=self.show_bar_chart)
        bar_btn.grid(row=0, column=0, padx=5)

        line_btn = tk.Button(chart_btn_frame, text="Artist Line Chart", command=self.show_line_chart)
        line_btn.grid(row=0, column=1, padx=5)

        pie_btn = tk.Button(chart_btn_frame, text=" Gener Pie Chart", command=self.show_pie_chart)
        pie_btn.grid(row=0, column=2, padx=5)
        self.song_listbox = tk.Listbox(root, height=10, width=100)
        self.song_listbox.pack(pady=10)
        self.song_listbox.bind("<Double-Button-1>", self.play_selected_song)

    def load_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not file_path:
            return

        self.data = pd.read_csv(file_path)
        years = sorted(self.data["year"].dropna().unique())
        genres = sorted(self.data["language"].dropna().unique())

        self.year_dropdown["values"] = ["All"] + [str(y) for y in years]
        self.genre_dropdown["values"] = ["All"] + genres

        self.year_var.set("All")
        self.genre_var.set("All")

    def apply_filters(self):
        if self.data is None:
            messagebox.showwarning("No Dataset", "Please upload a dataset first.")
            return

        df = self.data.copy()
        if self.year_var.get() != "All":
            df = df[df["year"] == int(self.year_var.get())]
        if self.genre_var.get() != "All":
            df = df[df["language"] == self.genre_var.get()]

        self.top_songs_data = df.sort_values("popularity", ascending=False).head(10)
        self.show_song_list()

    def show_song_list(self):
        self.song_listbox.delete(0, tk.END)
        if self.top_songs_data is not None:
            for idx, row in self.top_songs_data.iterrows():
                self.song_listbox.insert(tk.END, f"{row['track_name']} - {row['artist_name']}")

    def play_selected_song(self, event):
        if self.top_songs_data is None:
            return
        selection = self.song_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        song_url = self.top_songs_data.iloc[index]["track_url"]
        if pd.notna(song_url):
            webbrowser.open(song_url)

    def show_bar_chart(self):
        if self.top_songs_data is None:
            return
        plt.figure(num="Top Songs Popularity",figsize=(8,6))
        plt.barh(self.top_songs_data["track_name"], self.top_songs_data["popularity"], color="skyblue")
        plt.title("Top Songs by Popularity")
        plt.xlabel("Popularity")
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.show()

    def show_line_chart(self):
        if self.data is None:
            return

        df = self.apply_filter_copy()
        artist_trend = df.groupby(["year", "artist_name"])["popularity"].mean().reset_index()
        plt.figure(num="Artist Popularity Trend",figsize=(8,6))
        for artist in artist_trend["artist_name"].unique()[:5]: 
            artist_data = artist_trend[artist_trend["artist_name"] == artist]
            plt.plot(artist_data["year"], artist_data["popularity"], label=artist)
        plt.title("Artist Popularity Trend")
        plt.xlabel("Year")
        plt.ylabel("Popularity")
        plt.legend()
        plt.tight_layout()
        plt.show()

    def show_pie_chart(self):
        if self.data is None:
            return

        df = self.apply_filter_copy()
        lang_counts = df["language"].value_counts()
        plt.figure(num="Genre/Language Distribution",figsize=(6,6))
        plt.pie(lang_counts, labels=lang_counts.index, autopct="%1.1f%%")
        plt.title("Genre/Language Distribution")
        plt.tight_layout()
        plt.show()

    def apply_filter_copy(self):
        df = self.data.copy()
        if self.year_var.get() != "All":
            df = df[df["year"] == int(self.year_var.get())]
        if self.genre_var.get() != "All":
            df = df[df["language"] == self.genre_var.get()]
        return df


if __name__ == "__main__":
    root = tk.Tk()
    app = MusicApp(root)
    root.mainloop()
