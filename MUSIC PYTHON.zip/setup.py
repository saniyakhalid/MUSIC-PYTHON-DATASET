# screen setup
from tkinter import *
import tkinter
from PIL import Image, ImageTk
from pygame import mixer
mixer.init()
from tkinter import messagebox
from tkinter import filedialog
import os
from mutagen.mp3 import MP3 
import time
from mutagen import File
from mutagen.mp3 import MP3
import time
import subprocess
import warnings
warnings.filterwarnings("ignore")

class MusicPlayer:
    # created function self for automatically run
    def __init__(self, root):
        self.var = root
        self.var.title('MUSIC PLAYER')
        self.var.geometry('700x400')
        self.var.resizable(0,0)
        self.var.configure(background='white')
        #open file
        def OpenFile():
            global filename
            filename=filedialog.askopenfilename()
        #menu
        self.menubar=Menu(self.var)
        self.var.configure(menu=self.menubar)
        
        self.submenu=Menu(self.menubar,tearoff=0)
        self.menubar.add_cascade(label='File',menu=self.submenu)
        self.submenu.add_command(label='Open',command=OpenFile)
        self.submenu.add_command(label='Exit',command=self.var.destroy)
        def About():
            tkinter.messagebox.showinfo("About Us" , "THIS MUSIC PLAYER APP IS CREATED BY SANIYA SHIKALGAR")
        
        self.submenu2=Menu(self.menubar,tearoff=0)
        self.menubar.add_cascade(label='Help',menu=self.submenu2)
        self.submenu2.add_command(label='About',command=About)
        #add dataset menu
        self.submenu3=Menu(self.menubar,tearoff=0)
       # self.menubar.add_cascade(label='DATASET',menu=self.submenu3)
        self.submenu3.add_command(label="Dataset", command=self.open_dataset)
        self.menubar.add_cascade(label="DATASET", menu=self.submenu3)
        # adding label
        self.label = Label(self.var, text="Let's Started", bg='black', fg='white',font='22')
        self.label.place(x=50, y=20)
        #music name
        def songinfo():
            self.label['text']='CURRENT MUSIC :- '+os.path.basename(filename)
        #adding left side of image
        self.L_photo=ImageTk.PhotoImage(file='m2.jpg')
        L_photo=Label(self.var,image=self.L_photo,bg='white').place(x=135,y=80,width=500,height=250)

        # adding image
        self.photo = ImageTk.PhotoImage(file='m1.jpg')  # keep reference in self
        self.image_label = Label(self.var, image=self.photo,bg='white')
        self.image_label.place(x=5, y=60)
        #label
        self.label1=Label(self.var,text="LET'S PLAY IT!",bg='black',fg='white',font=20)
        self.label1.pack(side=BOTTOM,fill=X)#fill=X because complete background color for whole x
        #function to play music
        def playmusic():
            #pause music starts from stopped position
            try:
                paused
            except NameError:
                try:
                    mixer.music.load(filename)
                    mixer.music.play()
                    self.label1['text']='MUSIC  PLAYING'
                    songinfo()
                    length_bar()
                    
                    self.im1=ImageTk.PhotoImage(file='m6.jpg')
                    self.im2=ImageTk.PhotoImage(file='m9.jpg')
                    self.im3=ImageTk.PhotoImage(file='pr3.jpg')
                    self.im4=ImageTk.PhotoImage(file='pr4.jpg')
                    
                    self.imglabel=Label(self.var,text='',bg='white')
                    self.imglabel.place(x=5, y=60)
                    animation()

            
                except:
                    tkinter.messagebox.showerror('ERROR','FILE COULD NOT FOUND')
            else:
                mixer.music.unpause()
                self.label1['text']='Music_Unpaused'
         #label for length bar
        self.lengthbar=Label(self.var,text='TOTAL LENGTH:- 00:00',bg='black',fg='white',font=22)
        self.lengthbar.place(x=5,y=250)
        #length bar
        def length_bar():
            #starting from zero
            current_time=mixer.music.get_pos()/1000
            #convert current timein min sec
            convert_current_time=time.strftime('%M:%S',time.gmtime(current_time))
            #print(convert_current_time)
            #select mp3 songs
            song_mut=MP3(filename)
            #get length
            song_mut_length=song_mut.info.length
            #convert min sec
            convert_song_mut_length=time.strftime('%M:%S',time.gmtime(song_mut_length))
            #print(song_mut_length)
            # print(convert_song_mut_length)
            #blit on screen
            self.lengthbar.config(text=f"TOTAL LENGTH:- {convert_current_time} : {convert_song_mut_length}")
            self.lengthbar.after(1000,length_bar)

        #label for length bar
        #self.lengthbar=Label(self.var,text='TOTAL LENGTH:- 00:00',bg='black',fg='white',font=22).place(x=5,y=250)
        

        #creating button play
        self.B1=ImageTk.PhotoImage(file='p1.jpg')
        B1=Button(self.var,image=self.B1,bd=0,bg='white',command=playmusic)
        B1.place(x=5,y=300)
        #function pause music
        def pausemusic():
            global paused
            paused=TRUE
            mixer.music.pause()
            self.label1['text']='Music Paused'
        #creating button pause
        self.B2=ImageTk.PhotoImage(file='p2.jpg')
        B2=Button(self.var,image=self.B2,bd=0,bg='white',command=pausemusic).place(x=95,y=300)
        #function to stop music
        def stopmusic():
            mixer.music.stop()
            self.label1['text']='Music Stopped'
        #creating button stop
        self.B3=ImageTk.PhotoImage(file='s.jpg')
        B3=Button(self.var,image=self.B3,bd=0,bg='white',command=stopmusic).place(x=185,y=300)
        #Animation
        def animation():
            self.im1=self.im2
            self.im2=self.im3
            self.im3=self.im4
            self.im4=self.im1
            self.imglabel.config(image=self.im1)
            self.imglabel.after(3000,animation)
            
        #mute
        def mute():
            self.scale.set(0)
            mixer.music.set_volume(0)
            self.mute = ImageTk.PhotoImage(file='v4.jpg')
            self.volume_btn.config(image=self.mute, command=unmute)
        #unmute
        def unmute():
            self.scale.set(25)
            mixer.music.set_volume(0.25)
            self.Volume = ImageTk.PhotoImage(file='v3.jpg')
            self.volume_btn.config(image=self.Volume, command=mute)
        self.Volume = ImageTk.PhotoImage(file='v3.jpg')
        self.volume_btn = Button(self.var, image=self.Volume, command=mute, bg='white', bd=0)
        self.volume_btn.place(x=280, y=300)   # .place() on a separate line
        #volume image
        #self.Volume=ImageTk.PhotoImage(file='v3.jpg')
        #Volume=Button(self.var,image=self.Volume,bg='white',bd=0).place(x=280,y=310)
        #function for volume
        def v(vol):
            volume=int(vol)/100
            mixer.music.set_volume(volume)
        #volume bar
        self.scale=Scale(self.var,from_=0,to=100,bg='cyan',orient=HORIZONTAL,length=120,command=v)
        self.scale.set(25)
        mixer.music.set_volume(0.25)
        self.scale.place(x=390,y=310)
    def open_dataset(self):
        try:
            subprocess.Popen(["python", "dataset.py"])
        except Exception as e:
            messagebox.showerror("Error", f"Cannot open dataset.py:\n{e}")
# var, obj  is an object
var = Tk()
obj = MusicPlayer(var)

# mainloop will keep the program running
var.mainloop()
