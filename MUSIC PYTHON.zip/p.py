import tkinter as tk
from itertools import cycle
import subprocess
win_width = 350
win_height = 550
root = tk.Tk()
root.title("MUSIC")
root.resizable(0,0)
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width // 2) - (win_width // 2)
y = (screen_height // 2) - (win_height // 2)
root.geometry(f"{win_width}x{win_height}+{x}+{y}")
root.configure(bg="#E6E6FA")
frames = [tk.PhotoImage(file="music.gif", format=f"gif -index {i}") for i in range(10)]  
frame_cycle = cycle(frames)

label = tk.Label(root, bg="#E6E6FA")
label.pack(pady=50)

def animate():
    frame = next(frame_cycle)
    label.config(image=frame)
    root.after(100, animate)  
def start_app():
    animate()  
    subprocess.Popen(["python", "setup.py"])  
start_button = tk.Button(root, text=" Let's Start", font=("Arial", 22, "bold"), command=start_app, bg='#FFB6C1')
start_button.pack(pady=50)
root.mainloop()
